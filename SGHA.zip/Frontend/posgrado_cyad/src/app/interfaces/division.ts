export interface Division {
    id: number;
    division: string;
    activo: boolean;
}