export interface EstadoAspirante{
    id: number;
    estado: string;
    activo: boolean;
}