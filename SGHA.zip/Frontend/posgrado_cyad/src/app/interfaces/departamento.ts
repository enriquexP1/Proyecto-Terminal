export interface Departamento {
    id: number;
    departamento: string;
    activo: boolean;
}