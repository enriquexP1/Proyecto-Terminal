export interface Nivel{
    id: number;
    nivel: string;
    activo: boolean;
}