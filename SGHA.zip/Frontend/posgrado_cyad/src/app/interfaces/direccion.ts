export interface Direccion {
    id: number;
    calle: string;
    numero: number;
    colonia: string;
    cp: number;
    ciudad: string;
    delegacion_municipio: string;
    activo: boolean;
}