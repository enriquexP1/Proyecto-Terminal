import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lgac-table',
  templateUrl: './lgac-table.component.html',
  styleUrls: ['./lgac-table.component.scss']
})
export class LgacTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
