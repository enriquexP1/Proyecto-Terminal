import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lgac-detail',
  templateUrl: './lgac-detail.component.html',
  styleUrls: ['./lgac-detail.component.scss']
})
export class LgacDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
