package com.example.PosgradoCyad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PosgradoCyadApplicationTests {

	@Test
	void contextLoads() {
	}

}
